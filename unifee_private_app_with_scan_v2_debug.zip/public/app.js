const scanBtn = document.getElementById("scan-btn");
const scanStatus = document.getElementById("scan-status");
const fileInput = document.getElementById("invoiceFile");
const debugCard = document.getElementById("debug-card");
const debugJson = document.getElementById("debug-json");

function normalizeDate(v){
  if (!v || typeof v !== "string") return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const m = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  return "";
}
function setValue(id, value){
  const el = document.getElementById(id);
  if (!el) return;
  if (value === null || value === undefined || value === "") return;
  el.value = value;
}
function countFilled(data){
  const keys = ["supplier","annual_consumption_kwh","kwh_price_eur","subscription_annual_eur","turpe_annual_eur","taxes_annual_eur","subscribed_power_kva","max_power_used_kva","contract_end_date"];
  return keys.filter(k => data[k] !== null && data[k] !== undefined && data[k] !== "").length;
}

scanBtn.addEventListener("click", async () => {
  if (!fileInput.files?.length) {
    scanStatus.textContent = "Ajoute d'abord une photo de facture.";
    return;
  }
  const formData = new FormData();
  formData.append("invoice", fileInput.files[0]);

  scanStatus.textContent = "Analyse en cours...";
  debugCard.classList.add("hidden");
  debugJson.textContent = "";

  try {
    const res = await fetch("/api/extract-invoice", { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || data?.error || "Erreur API");

    setValue("supplier", data.supplier);
    setValue("consumption", data.annual_consumption_kwh);
    setValue("currentPrice", data.kwh_price_eur);
    setValue("currentSubscription", data.subscription_annual_eur);
    setValue("currentTurpe", data.turpe_annual_eur);
    setValue("currentTaxes", data.taxes_annual_eur);
    setValue("subscribedPower", data.subscribed_power_kva);
    setValue("maxPower", data.max_power_used_kva);
    setValue("contractEnd", normalizeDate(data.contract_end_date));
    setValue("notes", (data.notes || []).join(" | "));

    debugJson.textContent = JSON.stringify(data, null, 2);
    debugCard.classList.remove("hidden");

    const filled = countFilled(data);
    scanStatus.textContent = filled === 0
      ? "Extraction terminée, mais aucun champ exploitable n'a été détecté. Regarde la zone Debug extraction."
      : `Extraction terminée. ${filled} champ(s) détecté(s). Vérifie les champs puis lance le calcul.`;
  } catch (err) {
    scanStatus.textContent = "Erreur : " + err.message;
  }
});
