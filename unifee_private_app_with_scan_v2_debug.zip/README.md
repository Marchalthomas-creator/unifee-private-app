Version debug avec affichage JSON de l'extraction.
